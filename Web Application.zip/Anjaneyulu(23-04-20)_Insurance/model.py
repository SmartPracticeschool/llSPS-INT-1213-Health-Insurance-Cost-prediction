# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import pickle

dataset = pd.read_csv('insurance.csv')

dataset['smoker'].fillna(0, inplace=True)

dataset['sex'].fillna(0, inplace=True)

dataset['bmi'].fillna(dataset['bmi'].mean(), inplace=True)

X = dataset.iloc[:, :6]

#Converting words to integer values
def convert_to_int(word):
    word_dict = {'yes':1,'no':0,'female':1,'male':0,'northeast':0,'northwest':1,'southeast':2,'southwest':3, 0: 0}
    return word_dict[word]

X['smoker'] = X['smoker'].apply(lambda x : convert_to_int(x))

X['sex'] = X['sex'].apply(lambda x : convert_to_int(x))
X['region'] = X['region'].apply(lambda x : convert_to_int(x))
y = dataset.iloc[:, -1]

#Splitting Training and Test Set
#Since we have a very small dataset, we will train our model with all availabe data.
from sklearn.ensemble import RandomForestRegressor 
# create regressor object 
regressor = RandomForestRegressor(n_estimators = 100, random_state = 0)
# fit the regressor with x and y data 
regressor.fit(X, y)   
# Saving model to disk
pickle.dump(regressor, open('model.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('model.pkl','rb'))
print(model.predict([[48,0,30.2,2,0,3]]))